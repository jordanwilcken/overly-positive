# Extractor

Contains an integrations framework and a basic extractor for the First Plaidypus Bank.

### Install dependencies
```
make setup
```

### Build
```
make build
```

### Watch
```
make watch
```

Run the TypeScript compiler in watch mode. Watch input files and trigger recompilation on changes.

### Lint
```
make lint
```

Run tslint on the `src` directory.

### Run the extractor

Currently expects the First Plaidypus Bank website to be running at `firstplaidypus.herokuapp.com`. Requires Node 8+.

```
make extract
```

import {
  errorResult,
  ExtractorErrorCode,
} from '../framework/errors';
import { asyncRequest, createJar } from '../framework/requests';
import { Credentials } from '../framework/model';
import { LoginResult } from '../framework/plugin';

export const login = async (
  creds: Credentials,
): Promise<LoginResult> => {
	var
		theJar = createJar();

	return asyncRequest(
		'myUri',
		{
			method: "POST",
			jar: theJar
		}).then(response => {
			return { session: { jar: theJar } };
		})
		.catch(error => errorResult(ExtractorErrorCode.InvalidCredentials, error));
}

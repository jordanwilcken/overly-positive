// TODO: implement extractInfo
